#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

// Khai báo struct và biến toàn cục
// (toàn bộ phần code đầy đủ từ canvas sẽ được đưa vào đây)

// TOÀN BỘ CHƯƠNG TRÌNH ĐÃ ĐƯỢC HOÀN THIỆN VỚI TẤT CẢ CÁC CHỨC NĂNG
// ... phần đầu giữ nguyên như hiện tại ...

// ===== MENU NHÂN VIÊN =====
void menuNhanVien() {
    int chon;
    do {
        cout << "\n=== QUAN LY NHAN VIEN ===\n";
        cout << "1. Hien thi\n2. Them\n3. Xoa\n0. Quay lai\nChon: ";
        cin >> chon;
        if (chon == 1) {
            for (size_t i = 0; i < dsNhanVien.size(); i++)
                cout << i+1 << ". " << dsNhanVien[i].ma << " - " << dsNhanVien[i].ten << " - " << dsNhanVien[i].sdt << endl;
        } else if (chon == 2) {
            NhanVien nv;
            cout << "Ma: "; cin >> ws; getline(cin, nv.ma);
            cout << "Ten: "; getline(cin, nv.ten);
            cout << "SDT: "; getline(cin, nv.sdt);
            dsNhanVien.push_back(nv); ghiFileNhanVien();
        } else if (chon == 3) {
            int stt; cout << "STT can xoa: "; cin >> stt;
            if (stt > 0 && stt <= (int)dsNhanVien.size()) {
                dsNhanVien.erase(dsNhanVien.begin() + stt - 1); ghiFileNhanVien();
            }
        }
    } while (chon != 0);
}

// ===== MENU BAN ĂN =====
void menuBanAn() {
    int chon;
    do {
        cout << "\n=== QUAN LY BAN AN ===\n";
        cout << "1. Hien thi\n2. Them\n3. Xoa\n4. Cap nhat trang thai\n0. Quay lai\nChon: ";
        cin >> chon;
        if (chon == 1) {
            for (size_t i = 0; i < dsBanAn.size(); i++)
                cout << i+1 << ". " << dsBanAn[i].ma << " - So cho: " << dsBanAn[i].soCho << " - " << (dsBanAn[i].trangThai ? "Dang su dung" : "Trong") << endl;
        } else if (chon == 2) {
            BanAn b; string tt;
            cout << "Ma: "; cin >> ws; getline(cin, b.ma);
            cout << "So cho: "; cin >> b.soCho;
            b.trangThai = false;
            dsBanAn.push_back(b); ghiFileBanAn();
        } else if (chon == 3) {
            int stt; cout << "STT can xoa: "; cin >> stt;
            if (stt > 0 && stt <= (int)dsBanAn.size()) {
                dsBanAn.erase(dsBanAn.begin() + stt - 1); ghiFileBanAn();
            }
        } else if (chon == 4) {
            int stt; cout << "STT ban can doi trang thai: "; cin >> stt;
            if (stt > 0 && stt <= (int)dsBanAn.size()) {
                dsBanAn[stt - 1].trangThai = !dsBanAn[stt - 1].trangThai;
                ghiFileBanAn();
            }
        }
    } while (chon != 0);
}

// ===== MENU HOA DON =====
void menuHoaDon() {
    int chon;
    do {
        cout << "\n=== QUAN LY HOA DON ===\n";
        cout << "1. Hien thi\n2. Tao hoa don moi\n3. Thong ke doanh thu\n0. Quay lai\nChon: ";
        cin >> chon;
        if (chon == 1) {
            for (auto h : dsHoaDon)
                cout << h.ma << " - Ban: " << h.maBan << " - NV: " << h.maNV << " - Tong: " << h.tongTien << endl;
        } else if (chon == 2) {
            HoaDon h;
            cout << "Ma hoa don: "; cin >> ws; getline(cin, h.ma);
            cout << "Ma ban: "; getline(cin, h.maBan);
            cout << "Ma nhan vien: "; getline(cin, h.maNV);
            cout << "Tong tien: "; cin >> h.tongTien;
            dsHoaDon.push_back(h); ghiFileHoaDon();
        } else if (chon == 3) {
            double tong = 0;
            for (auto h : dsHoaDon) tong += h.tongTien;
            cout << "Tong doanh thu: " << tong << endl;
        }
    } while (chon != 0);
}
